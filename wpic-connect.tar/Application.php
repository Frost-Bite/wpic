<?php
/**
 * @brief		Sends emails about replies to comments in wp through the IC mail system and adds search with parameter ?s=
 * @author		Khovl
 * @copyright	(c) 2016 
 * @package		IPS Community Suite
 * @subpackage	domain.com
 * @since		17 Dec 2016
 * @version		1.0.9
 */
 
namespace IPS\siteconnect;

/**
 * Application Class
 */
class _Application extends \IPS\Application
{

}