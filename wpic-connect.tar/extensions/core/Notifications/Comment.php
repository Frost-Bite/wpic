<?php
/**
 * @brief		Notification Options
 * @author		<a href='http://www.invisionpower.com'>Invision Power Services, Inc.</a>
 * @copyright	(c) 2001 - 2016 Invision Power Services, Inc.
 * @license		http://www.invisionpower.com/legal/standards/
 * @package		IPS Community Suite
 * @subpackage	ProGamer.Ru
 * @since		17 Dec 2016
 * @version		SVN_VERSION_NUMBER
 */

namespace IPS\siteconnect\extensions\core\Notifications;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Notification Options
 */
class _Comment
{
	/**
	 * Get configuration
	 *
	 * @param	\IPS\Member	$member	The member
	 * @return	array
	 */
	public function getConfiguration( $member )
	{
		// Basically just return a list of the keys for the types of notification your app will send
		// keys can be anything you want. You can specify what should be the default value and any disabled values (acceptable values are "email" and "inline")
		// For each key, create a language string "notifications__<key>" which is what will display in the user's Notification Options screen
		
		return array(
			'reply'	=> array( 'default' => array( 'inline' ), 'disabled' => array() ),
		);
	}
	
	// For each type of notification you need a method like this which controls what will be displayed when the user clicks on the notification icon in the header:
	// Note that for each type of notification you must *also* create email templates. See documentation for details: https://remoteservices.invisionpower.com/docs/devdocs-notifications
	
	/**
	 * Parse notification: reply
	 *
	 * @param	\IPS\Notification\Inline	$notification	The notification
	 * @return	array
	 * @code
	 return array(
		 'title'		=> "Mark has replied to A Topic",	// The notification title
		 'url'			=> \IPS\Http\Url::internal( ... ),	// The URL the notification should link to
		 'content'		=> "Lorem ipsum dolar sit",			// [Optional] Any appropriate content. Do not format this like an email where the text
		 													// 	 explains what the notification is about - just include any appropriate content.
		 													// 	 For example, if the notification is about a post, set this as the body of the post.
		 'author'		=>  \IPS\Member::load( 1 ),			// [Optional] The user whose photo should be displayed for this notification
	 );
	 * @endcode
	 */
	public function parse_reply( \IPS\Notification\Inline $notification )
	{
	    
        $postId = $notification->extra[0];
        $commentId = $notification->extra[1];

        $prefix = \IPS\Db::i()->prefix;
        \IPS\Db::i()->prefix = '';

        $postTitle = \IPS\Db::i()->select('post_title', 'wp_posts', array('ID = ?', $postId))->first();
        $commentAuthorId = \IPS\Db::i()
            ->select('meta_value', 'wp_commentmeta', array('comment_id = ? AND meta_key = ?', $commentId, 'ipb_member_id'));

        if (!$commentAuthorId->count()) {

            \IPS\Db::i()->prefix = $prefix;
            throw new \OutOfRangeException;

        } else {

            $commentAuthorId = \IPS\Db::i()
                ->select('meta_value', 'wp_commentmeta', array('comment_id = ? AND meta_key = ?', $commentId, 'ipb_member_id'))->first();

        }



        \IPS\Db::i()->prefix = $prefix;

        $author = \IPS\Member::load($commentAuthorId);
        $title = $author->name . ' ответил на ваш комментарий к записи "' . $postTitle . '"';


		return array(
			'title'		=> $title,	// The notification title
			'url'			=> 'https://www.progamer.ru/?p=' . $postId . '#comment-' . $commentId,	// The URL the notification should link to
			'content'		=> '',			// [Optional] Any appropriate content. Do not format this like an email where the text
																// 	 explains what the notification is about - just include any appropriate content.
																// 	 For example, if the notification is about a post, set this as the body of the post.
			'author'		=>  $author,			// [Optional] The user whose photo should be displayed for this notification
		);
	}
}