//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class siteconnect_hook_blog_search extends _HOOK_CLASS_
{

	/* !Hook Data - DO NOT REMOVE */
public static function hookData() {
 return array_merge_recursive( array (
  'navBar' => 
  array (
    0 => 
    array (
      'selector' => '#elSearchFilter_menu > li[data-role=\'globalSearchMenuOptions\']',
      'type' => 'add_before',
      'content' => '{{if output.defaultSearchOption[0] == \'all\'}}
<li class="ipsMenu_item " data-ipsmenuvalue="blog">
    <a href="#">Статьи</a>
</li>
{{endif}}',
    ),
    1 => 
    array (
      'selector' => '#elSearch > form[accept-charset=\'utf-8\']',
      'type' => 'add_attribute',
      'attributes_add' => 
      array (
        0 => 
        array (
          'key' => 'onSubmit',
          'value' => 'if (jQuery(\'#elSearch form input[name=type]\').val() == \'blog\') { jQuery(\'#elSearch form\').attr(\'action\', location.protocol + \'//\' + location.host);  jQuery(\'#elSearch form\').attr(\'method\', \'get\'); jQuery(\'#elSearch #elSearchField\').attr(\'name\', \'s\'); }',
        ),
      ),
    ),
    2 => 
    array (
      'selector' => '#elSearchFilter_menu',
      'type' => 'add_inside_start',
      'content' => '{{if output.defaultSearchOption[0] == \'blog\'}}
<li class="ipsMenu_item ipsMenu_itemChecked" data-ipsmenuvalue="blog">
    <a href="#">Статьи</a>
</li>
{{endif}}',
    ),
  ),
  'quickSearch' => 
  array (
    0 => 
    array (
      'selector' => '#elSearchExpanded > ul.ipsSideMenu_list.ipsSideMenu_withRadios.ipsSideMenu_small.ipsType_normal[data-ipssidemenu-type=\'radio\'][data-ipssidemenu-responsive=\'false\'][data-role=\'searchContexts\'] > li:eq(0)',
      'type' => 'add_after',
      'content' => '<li>
	<span class="ipsSideMenu_item" data-ipsmenuvalue="blog">
		<input type="radio" name="type" value="blog" checked="" id="elQuickSearchRadio_type_blog">
		<label for="elQuickSearchRadio_type_blog" id="elQuickSearchRadio_type_blog_label">Статьи</label>
	</span>
</li>',
    ),
    1 => 
    array (
      'selector' => '#elSearch > form[accept-charset=\'utf-8\'][method=\'post\']',
      'type' => 'add_attribute',
      'attributes_add' => 
      array (
        0 => 
        array (
          'key' => 'onSubmit',
          'value' => 'if ( jQuery(\'#elSearch form input[name="type"][value="blog"]\').is(\':checked\') ) { jQuery(\'#elSearch form\').attr(\'action\', location.protocol + \'//\' + location.host);  jQuery(\'#elSearch form\').attr(\'method\', \'get\'); jQuery(\'#elSearch #elSearchField\').attr(\'name\', \'s\'); }',
        ),
      ),
    ),
  ),
), parent::hookData() );
}
/* End Hook Data */


}
