//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class siteconnect_hook_blog_search_table extends _HOOK_CLASS_
{

/* !Hook Data - DO NOT REMOVE */
public static function hookData() {
 return array_merge_recursive( array (
  'filters' => 
  array (
    0 => 
    array (
      'selector' => '#elTabs_search > ul[role=\'tablist\']',
      'type' => 'add_inside_end',
      'content' => '<li>
	<a href=\'#\' id="elTab_searchBlog" class="ipsTabs_item ipsType_center" title="Поиск по статьям" role="tab">
		Поиск статей
	</a>
</li>',
    ),
    1 => 
    array (
      'selector' => '#elTabs_search_content',
      'type' => 'add_inside_end',
      'content' => '<div id=\'ipsTabs_elTabs_search_elTab_searchBlog_panel\' class=\'ipsTabs_panel\' data-tabType=\'blog\'>

</div>',
    ),
    2 => 
    array (
      'selector' => '#elSearchFilters_content',
      'type' => 'add_attribute',
      'attributes_add' => 
      array (
        0 => 
        array (
          'key' => 'onSubmit',
          'value' => 'if (jQuery(\'form#elSearchFilters_content #elTab_searchBlog\').is(\'[aria-selected=true]\')) { window.location = location.protocol + \'//\' + location.host + \'/?s=\' + jQuery(\'form#elSearchFilters_content #elMainSearchInput\').val(); return false;}',
        ),
      ),
    ),
  ),
), parent::hookData() );
}
/* End Hook Data */


}
