//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}


class siteconnect_hook_blog_logout extends _HOOK_CLASS_
{

	protected function manage()
	{
		/* Did we just log in? */
		if ( \IPS\Member::loggedIn()->member_id and isset( \IPS\Request::i()->_fromLogin ) )
		{
			\IPS\Output::i()->redirect( \IPS\Http\Url::internal('') );
		}

		/* Init login class */
		$login = new \IPS\Login( \IPS\Http\Url::internal( "app=core&module=system&controller=login", 'front', 'login' ) );

		/* What's our referrer? */
		$ref = \IPS\Request::i()->ref;

		/* Process */
		$error = NULL;
		try
		{
			if ( $success = $login->authenticate() )
			{
				if ( $ref and $ref = @base64_decode( $ref ) )
				{
					try
					{
						$ref = \IPS\Http\Url::createFromString( $ref );
						if ( !( $ref instanceof \IPS\Http\Url\Internal ) or $ref->base !== 'front' )
						{
							//throw new \Exception;
						}
					}
					catch ( \Exception $e )
					{
						$ref = \IPS\Http\Url::internal('');
					}
				}
				else
				{
					$ref = \IPS\Http\Url::internal('');
				}

				if ( $success->mfa() )
				{
					$_SESSION['processing2FA'] = array( 'memberId' => $success->member->member_id, 'anonymous' => $success->anonymous, 'remember' => $success->rememberMe, 'destination' => (string) $ref, 'handler' => $success->handler->id );
					\IPS\Output::i()->redirect( $ref->setQueryString( '_mfaLogin', 1 ) );
				}
				$success->process();

				\IPS\Output::i()->redirect( $ref->setQueryString( '_fromLogin', 1 ) );
			}
		}
		catch ( \IPS\Login\Exception $e )
		{
			if ( $e->getCode() === \IPS\Login\Exception::MERGE_SOCIAL_ACCOUNT )
			{
				$e->member = $e->member->member_id;
				$e->handler = $e->handler->id;
				$_SESSION['linkAccounts'] = json_encode( $e );

				\IPS\Output::i()->redirect( \IPS\Http\Url::internal( 'app=core&module=system&controller=login&do=link', 'front', 'login' )->setQueryString( 'ref', $ref ), '', 303 );
			}

			$error = $e->getMessage();
		}

		/* Display Login Form */
		\IPS\Output::i()->allowDefaultWidgets = FALSE;
		\IPS\Output::i()->bodyClasses[] = 'ipsLayout_minimal';
		\IPS\Output::i()->sidebar['enabled'] = FALSE;
		\IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('login');
		\IPS\Output::i()->output = \IPS\Theme::i()->getTemplate( 'system' )->login( $login, $ref, $error );

		/* Set Session Location */
		\IPS\Session::i()->setLocation( \IPS\Http\Url::internal( 'app=core&module=system&controller=login', NULL, 'login' ), array(), 'loc_logging_in' );
	}

	/**
	 * Log Out
	 *
	 * @return void
	 */
	protected function logout()
	{
		$member = \IPS\Member::loggedIn();

		/* CSRF Check */
		\IPS\Session::i()->csrfCheck();

		/* Work out where we will be going after log out */
		if (isset($_GET['ref'])) {
			$referrer = \IPS\Http\Url::createFromString( base64_decode($_GET['ref']) );
			$redirectUrl = $referrer;
		}
		elseif( !empty( $_SERVER['HTTP_REFERER'] ) )
		{
			$referrer = \IPS\Http\Url::createFromString( $_SERVER['HTTP_REFERER'] );
			$redirectUrl = ( $referrer instanceof \IPS\Http\Url\Internal and ( !isset( $referrer->queryString['do'] ) or $referrer->queryString['do'] != 'validating' ) ) ? $referrer : \IPS\Http\Url::internal('');
		}
		else
		{
			$redirectUrl = \IPS\Http\Url::internal( '' );
		}


		/* Are we logging out back to an admin user? */
		if( isset( $_SESSION['logged_in_as_key'] ) )
		{
			$key = $_SESSION['logged_in_as_key'];
			unset( \IPS\Data\Store::i()->$key );
			unset( $_SESSION['logged_in_as_key'] );
			unset( $_SESSION['logged_in_from'] );

			\IPS\Output::i()->redirect( $redirectUrl );
		}

		/* Do not allow the login_key to be re-used */
		if ( isset( \IPS\Request::i()->cookie['device_key'] ) )
		{
			try
			{
				$device = \IPS\Member\Device::loadAndAuthenticate( \IPS\Request::i()->cookie['device_key'], $member );
				$device->login_key = NULL;
				$device->save();
			}
			catch ( \OutOfRangeException $e ) { }
		}

		/* Clear cookies */
		\IPS\Request::i()->clearLoginCookies();

		/* Destroy the session (we have to explicitly reset the session cookie, see http://php.net/manual/en/function.session-destroy.php) */
		$_SESSION = array();
		$params = session_get_cookie_params();
		setcookie( session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"] );
		session_destroy();

		/* Member sync callback */
		$member->memberSync( 'onLogout', array( $redirectUrl ) );

		/* Redirect */
		\IPS\Output::i()->redirect( $redirectUrl->setQueryString( '_fromLogout', 1 ) );
	}

}